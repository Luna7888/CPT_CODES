
# Nome do Software: 
  Medidor de Temperatura - Arduino

# Objetivo do Software:
  O software foi desenvolvido para realizar o controle preciso da temperatura utilizando um microcontrolador Arduino. Ele é projetado para determinar a curva de aquecimento ideal para um líquido específico, acionando e desativando a placa de aquecimento conforme necessário, enquanto monitora continuamente a temperatura. Os dados de temperatura são armazenados em um arquivo TXT de acordo com o intervalo definido.

# Interface Principal Desenvolvida:
![image](https://github.com/MattheusOliveiraBatista/Medidor-de-Temperatura/assets/70457897/0286f328-df31-44eb-a079-e261acdb1a34)

# Interface Desenvolvida Para Exibir Temperatura em Função da Equação:
![image](https://github.com/MattheusOliveiraBatista/Medidor-de-Temperatura/assets/70457897/bd6c4cd0-73d8-4375-b392-eb11a7747b09)
